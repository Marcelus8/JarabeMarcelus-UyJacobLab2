package com.car;

public class PickupTruck extends Car{

	
	
	public PickupTruck(int speed, String shift, boolean seatBeltworn)
    {
		super(speed, shift, seatBeltworn);
		
	}
	public void DriveOffroad() {
		System.out.println("Car is now on Offroad Mode");
	}
	
	public void capacity() {
		System.out.println("This car has 5 seaters with a bed storage");
	}
}
