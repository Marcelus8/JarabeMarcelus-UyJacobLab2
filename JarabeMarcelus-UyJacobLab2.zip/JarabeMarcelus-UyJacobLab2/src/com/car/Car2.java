package com.car;


import java.util.Scanner;
public class Car2 {

	public static void main(String[] args) {
		
		  Car carObj = new Car(0, "", false);
		  PickupTruck pick = new PickupTruck(0,"",false);
		Scanner scan = new Scanner(System.in);
		System.out.println("Are you using Pickup Truck?(yes/no)");
		
		String car = scan.nextLine();
		
	    Car array[] = new Car[2];
	    array[0]= new PickupTruck(0,"", false);
	    array[1] = new Car(0,"",false);
	    
	 if (car.equalsIgnoreCase("yes")) {
		 System.out.println("you have chosen Pickup Truck");
		 array[0].capacity();
	 }
	 else {
		 System.out.println("you have chosen sedan as default");
		 array[1].capacity();
	 }
	 
	        carObj.buttonForswitchingCarOn();
	        carObj.seatBeltsensor();
	        carObj.currentSpeed();
	        
	        
	        if (car.equalsIgnoreCase("yes")) {
	   		 System.out.println("This car can go Off Road, enter OFFROAD to do so");
	   		 String choice = scan.nextLine();
	   		 
	   		 if(choice.equalsIgnoreCase("OFFROAD")) {
	   			 pick.DriveOffroad();
	   		 
	        }
	       
	        }
	        String shift = carObj.gearShift();
	        System.out.println("Car is now on " +  carObj.gearShift()+ " mode");
	        System.out.println("The car is now running "+ carObj.getSpeed() + " kmh");
	            
	
	        carObj.buttonCarOff();
	}}


